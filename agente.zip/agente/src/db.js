import mysql from 'mysql2/promise';
import { config } from './config.js';

let pool;

export function db() {
  if (!pool) {
    pool = mysql.createPool({
      ...config.db,
      waitForConnections: true,
      connectionLimit: 4,
      charset: 'utf8mb4',
      dateStrings: ['DATE'],
      timezone: 'Z',
    });
  }
  return pool;
}

export async function cerrarDB() {
  if (pool) await pool.end();
  pool = undefined;
}

// Nunca se guarda el cuerpo de los mails: solo datos administrativos.
const TABLAS = [
  `CREATE TABLE IF NOT EXISTS buzon_estado (
    buzon VARCHAR(20) PRIMARY KEY,
    uidvalidity BIGINT NOT NULL,
    ultimo_uid BIGINT NOT NULL,
    actualizado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) CHARACTER SET utf8mb4`,

  `CREATE TABLE IF NOT EXISTS mails_procesados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buzon VARCHAR(20) NOT NULL,
    uid BIGINT NOT NULL,
    message_id VARCHAR(500),
    remitente VARCHAR(320),
    asunto VARCHAR(500),
    resultado VARCHAR(20) NOT NULL,
    detalle VARCHAR(1000),
    intentos INT NOT NULL DEFAULT 0,
    procesado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY buzon_uid (buzon, uid)
  ) CHARACTER SET utf8mb4`,

  `CREATE TABLE IF NOT EXISTS seguimientos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(320) NOT NULL,
    nombre VARCHAR(200),
    categoria VARCHAR(40) NOT NULL,
    estado VARCHAR(30) NOT NULL,
    resumen VARCHAR(500),
    proxima_accion VARCHAR(500),
    fecha_proxima_accion DATE NULL,
    buzon VARCHAR(20),
    ultimo_message_id VARCHAR(500),
    ultimo_asunto VARCHAR(500),
    recordatorios INT NOT NULL DEFAULT 0,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    actualizado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_estado_fecha (estado, fecha_proxima_accion)
  ) CHARACTER SET utf8mb4`,

  `CREATE TABLE IF NOT EXISTS borradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buzon_origen VARCHAR(20),
    buzon_borrador VARCHAR(20),
    para VARCHAR(320),
    asunto VARCHAR(500),
    idioma VARCHAR(10),
    nota_interna VARCHAR(1000),
    es_recordatorio TINYINT NOT NULL DEFAULT 0,
    modo_prueba TINYINT NOT NULL DEFAULT 0,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) CHARACTER SET utf8mb4`,

  `CREATE TABLE IF NOT EXISTS alertas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buzon VARCHAR(20),
    remitente VARCHAR(320),
    asunto VARCHAR(500),
    motivo VARCHAR(500),
    origen VARCHAR(20),
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) CHARACTER SET utf8mb4`,

  `CREATE TABLE IF NOT EXISTS meta (
    clave VARCHAR(50) PRIMARY KEY,
    valor VARCHAR(200)
  ) CHARACTER SET utf8mb4`,
];

export async function inicializarDB() {
  for (const sql of TABLAS) await db().query(sql);
}

export async function leerMeta(clave) {
  const [filas] = await db().query('SELECT valor FROM meta WHERE clave = ?', [clave]);
  return filas[0]?.valor ?? null;
}

export async function guardarMeta(clave, valor) {
  await db().query(
    'INSERT INTO meta (clave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)',
    [clave, String(valor)],
  );
}

/** Recorta strings para que entren en las columnas VARCHAR. */
export function corto(texto, max) {
  if (texto === undefined || texto === null) return null;
  const s = String(texto).replace(/\s+/g, ' ').trim();
  return s.length > max ? s.slice(0, max - 1) + '…' : s;
}
