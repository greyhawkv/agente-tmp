// Prueba todas las conexiones. Uso: npm run probar
// (El agente también hace esta prueba solo, cada vez que arranca.)

let verificarConexiones;
try {
  ({ verificarConexiones } = await import('../src/verificar.js'));
} catch (e) {
  console.log(`✗ Configuración: ${e.message}\n  Completá configuracion.env.`);
  process.exit(1);
}
const { cerrarDB } = await import('../src/db.js');
const { fallas, texto } = await verificarConexiones();
console.log(texto);
await cerrarDB();
process.exit(fallas ? 1 : 0);
