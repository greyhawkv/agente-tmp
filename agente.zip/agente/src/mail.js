import { logError } from './log.js';
import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import { config } from './config.js';

// ─────────────────────────────────────────────────────────────
// Conexiones
// ─────────────────────────────────────────────────────────────

function nuevoCliente(buzon) {
  const cliente = new ImapFlow({
    host: config.imap.host,
    port: config.imap.port,
    secure: true,
    auth: { user: buzon.email, pass: buzon.clave },
    logger: false,
  });
  // Sin este manejador, un corte de conexión tiraría abajo todo el proceso (incluido el gestor).
  cliente.on('error', (e) => logError(`IMAP ${buzon.email}: ${e.message}`));
  return cliente;
}

async function carpetasEspeciales(cliente) {
  const lista = await cliente.list();
  const buscar = (uso, patron, porDefecto) =>
    lista.find((c) => c.specialUse === uso)?.path ||
    lista.find((c) => patron.test(c.path))?.path ||
    porDefecto;
  return {
    enviados: buscar('\\Sent', /^(sent|envoy|enviad)/i, 'Sent'),
    borradores: buscar('\\Drafts', /^(drafts|brouillon|borrador)/i, 'Drafts'),
    todas: lista.map((c) => c.path),
  };
}

/**
 * Abre una conexión IMAP por buzón.
 * Devuelve un Map: id del buzón → { buzon, cliente, carpetas }.
 */
export async function abrirBuzones() {
  const conexiones = new Map();
  try {
    for (const buzon of config.buzones) {
      const cliente = nuevoCliente(buzon);
      await cliente.connect();
      const carpetas = await carpetasEspeciales(cliente);
      conexiones.set(buzon.id, { buzon, cliente, carpetas });
    }
  } catch (e) {
    await cerrarBuzones(conexiones);
    throw e;
  }
  return conexiones;
}

export async function cerrarBuzones(conexiones) {
  for (const { cliente } of conexiones.values()) {
    try {
      await cliente.logout();
    } catch {
      /* ya cerrada */
    }
  }
}

// ─────────────────────────────────────────────────────────────
// Lectura (siempre en modo solo lectura: nunca marca mails como leídos)
// ─────────────────────────────────────────────────────────────

async function conCarpeta(cliente, carpeta, fn) {
  const lock = await cliente.getMailboxLock(carpeta, { readOnly: true });
  try {
    return await fn();
  } finally {
    lock.release();
  }
}

/** Estado de la bandeja de entrada: uidValidity y uidNext. */
export async function estadoInbox(conexion) {
  return conCarpeta(conexion.cliente, 'INBOX', async () => ({
    uidvalidity: String(conexion.cliente.mailbox.uidValidity),
    uidNext: Number(conexion.cliente.mailbox.uidNext),
  }));
}

/** UIDs de la bandeja de entrada posteriores a `desdeUid` (o recibidos desde una fecha). */
export async function uidsNuevos(conexion, { desdeUid, desdeFecha }) {
  return conCarpeta(conexion.cliente, 'INBOX', async () => {
    const criterio = desdeFecha ? { since: desdeFecha } : { uid: `${desdeUid + 1}:*` };
    const uids = (await conexion.cliente.search(criterio, { uid: true })) || [];
    return uids
      .map(Number)
      .filter((u) => desdeFecha || u > desdeUid)
      .sort((a, b) => a - b);
  });
}

/** Trae y parsea mensajes de una carpeta por UID. */
export async function traerMensajes(conexion, carpeta, uids) {
  if (!uids.length) return [];
  return conCarpeta(conexion.cliente, carpeta, async () => {
    const crudos = await conexion.cliente.fetchAll(uids.join(','), { uid: true, source: true }, { uid: true });
    const salida = [];
    for (const m of crudos) {
      const mail = await parsearMail(m.source);
      salida.push({ uid: Number(m.uid), carpeta, buzon: conexion.buzon.id, mail });
    }
    return salida;
  });
}

async function buscarUids(conexion, carpeta, criterio) {
  if (carpeta !== 'INBOX' && !conexion.carpetas.todas.includes(carpeta)) return [];
  return conCarpeta(conexion.cliente, carpeta, async () =>
    ((await conexion.cliente.search(criterio, { uid: true })) || []).map(Number),
  );
}

// ─────────────────────────────────────────────────────────────
// Parseo y limpieza
// ─────────────────────────────────────────────────────────────

function direcciones(campo) {
  if (!campo) return [];
  const grupos = Array.isArray(campo) ? campo : [campo];
  return grupos.flatMap((g) => g.value || []).map((v) => (v.address || '').toLowerCase()).filter(Boolean);
}

function cabecera(headers, nombre) {
  const v = headers.get(nombre);
  if (v === undefined || v === null) return '';
  if (typeof v === 'string') return v;
  return v.value ? String(v.value) : String(v);
}

export async function parsearMail(source) {
  const p = await simpleParser(source);
  const de = p.from?.value?.[0] || {};
  const responderA = p.replyTo?.value?.[0]?.address || de.address || '';
  const refs = p.references ? (Array.isArray(p.references) ? p.references : [p.references]) : [];
  return {
    messageId: p.messageId || null,
    inReplyTo: p.inReplyTo || null,
    references: refs,
    de: { email: (de.address || '').toLowerCase(), nombre: de.name || '' },
    responderA: responderA.toLowerCase(),
    para: direcciones(p.to),
    cc: direcciones(p.cc),
    asunto: p.subject || '',
    fecha: p.date ? p.date.toISOString() : null,
    texto: p.text || '',
    adjuntos: (p.attachments || [])
      .filter((a) => a.contentDisposition !== 'inline')
      .map((a) => a.filename || '(sin nombre)'),
    cabeceras: {
      autoSubmitted: cabecera(p.headers, 'auto-submitted').toLowerCase(),
      precedence: cabecera(p.headers, 'precedence').toLowerCase(),
      // mailparser agrupa las cabeceras List-* bajo la clave "list"
      listUnsubscribe: p.headers.has('list-unsubscribe') || Boolean(p.headers.get('list')?.unsubscribe),
      delAgente: p.headers.has('x-cabinet-agente'),
    },
  };
}

const INICIO_CITA = [
  /^\s*(le|el|on|am)\b.{0,200}(a écrit|a ecrit|escribió|escribio|wrote|schrieb)\s*:?\s*$/i,
  /(a écrit|escribió|wrote)\s*:\s*$/i,
  /^-{2,}\s*(original message|message d'origine|mensaje original|ursprüngliche nachricht)/i,
  /^_{8,}\s*$/,
];
const ENCABEZADO_REENVIO = /^(de|from|von)\s*:\s*\S/i;
const SEGUNDA_LINEA_REENVIO = /^(envoyé|envoye|sent|enviado|date|fecha|gesendet)\s*:/i;

/** Quita el historial citado y deja solo lo que escribió la persona en este mensaje. */
export function limpiarTexto(texto, max = 6000) {
  const lineas = String(texto || '').replace(/\r/g, '').split('\n');
  const salida = [];
  for (let i = 0; i < lineas.length; i++) {
    const l = lineas[i];
    if (INICIO_CITA.some((re) => re.test(l))) break;
    if (ENCABEZADO_REENVIO.test(l) && lineas.slice(i + 1, i + 4).some((x) => SEGUNDA_LINEA_REENVIO.test(x))) break;
    if (/^\s*>/.test(l)) continue;
    salida.push(l);
  }
  const limpio = salida.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return limpio.length > max ? limpio.slice(0, max) + '\n[…recortado]' : limpio;
}

export function normalizarAsunto(asunto) {
  let s = String(asunto || '').trim();
  const prefijo = /^\s*(re|tr|fw|fwd|aw|wg|rv|réf|ref)\s*(\[\d+\])?\s*:\s*/i;
  while (prefijo.test(s)) s = s.replace(prefijo, '');
  return s.trim();
}

// ─────────────────────────────────────────────────────────────
// Búsquedas para las herramientas del agente
// ─────────────────────────────────────────────────────────────

function involucra(mail, email) {
  return mail.de.email === email || mail.para.includes(email) || mail.cc.includes(email);
}

function resumenMensaje(m, largoTexto) {
  return {
    fecha: m.mail.fecha,
    buzon: m.buzon,
    direccion: m.carpeta === 'INBOX' ? 'recibido' : 'enviado por el cabinet',
    de: m.mail.de.nombre ? `${m.mail.de.nombre} <${m.mail.de.email}>` : m.mail.de.email,
    para: m.mail.para.join(', '),
    asunto: m.mail.asunto,
    adjuntos: m.mail.adjuntos,
    texto: limpiarTexto(m.mail.texto, largoTexto),
  };
}

function ordenarPorFecha(lista) {
  return lista.sort((a, b) => String(a.mail.fecha).localeCompare(String(b.mail.fecha)));
}

/** Últimos mails intercambiados con una dirección, en todos los buzones. */
export async function buscarHistorial(conexiones, email, max = 10) {
  const encontrados = [];
  for (const cx of conexiones.values()) {
    const recibidos = (await buscarUids(cx, 'INBOX', { from: email })).slice(-max);
    const enviados = (await buscarUids(cx, cx.carpetas.enviados, { to: email })).slice(-max);
    encontrados.push(...(await traerMensajes(cx, 'INBOX', recibidos)));
    encontrados.push(...(await traerMensajes(cx, cx.carpetas.enviados, enviados)));
  }
  return ordenarPorFecha(encontrados)
    .slice(-max)
    .reverse()
    .map((m) => resumenMensaje(m, 400));
}

/** Hilo de un mail: mismos asunto y corresponsal, o referenciado en sus cabeceras. */
export async function leerHilo(conexiones, mail, corresponsal) {
  const base = normalizarAsunto(mail.asunto);
  const referencias = new Set([...(mail.references || []), mail.inReplyTo].filter(Boolean));
  const vistos = new Set();
  const hilo = [];
  for (const cx of conexiones.values()) {
    for (const carpeta of ['INBOX', cx.carpetas.enviados]) {
      const uids = base ? (await buscarUids(cx, carpeta, { subject: base })).slice(-15) : [];
      for (const m of await traerMensajes(cx, carpeta, uids)) {
        const id = m.mail.messageId || `${m.buzon}:${carpeta}:${m.uid}`;
        if (vistos.has(id)) continue;
        if (involucra(m.mail, corresponsal) || referencias.has(m.mail.messageId)) {
          vistos.add(id);
          hilo.push(m);
        }
      }
    }
  }
  return ordenarPorFecha(hilo)
    .slice(-10)
    .map((m) => resumenMensaje(m, 1500));
}

// ─────────────────────────────────────────────────────────────
// Escritura: solo guardar borradores (APPEND). Nunca envía ni borra.
// ─────────────────────────────────────────────────────────────

export async function guardarEnCarpeta(conexion, carpeta, mensajeCrudo) {
  if (!conexion.carpetas.todas.includes(carpeta)) {
    await conexion.cliente.mailboxCreate(carpeta);
    conexion.carpetas.todas.push(carpeta);
  }
  await conexion.cliente.append(carpeta, mensajeCrudo, ['\\Draft', '\\Seen']);
}
