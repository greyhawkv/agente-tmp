// Todos los mensajes del agente llevan el prefijo [agente], para distinguirlos
// de los del gestor cuando comparten la misma consola.
export const log = (...a) => console.log('[agente]', ...a);
export const logError = (...a) => console.error('[agente]', ...a);
