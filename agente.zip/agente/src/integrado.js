// Punto de entrada para correr el agente dentro del proceso del gestor.
// En el archivo principal del gestor se agrega UNA línea al final:
//
//   import('./agente/src/integrado.js').catch((e) => console.error('[agente] no arrancó:', e.message));
//
// El agente no abre ningún puerto ni toca nada del gestor: solo programa sus ciclos.
import { iniciarAgente } from './arranque.js';

await iniciarAgente();
