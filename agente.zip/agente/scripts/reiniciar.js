// Borra el tracker y el historial del agente (por ejemplo, al terminar las pruebas).
// No toca los buzones. Uso: npm run reiniciar -- --si
import { db, inicializarDB, cerrarDB } from '../src/db.js';

if (!process.argv.includes('--si')) {
  console.log('Esto borra seguimientos, borradores registrados, alertas y el punto de partida de cada buzón.');
  console.log('Los mails y los borradores guardados en los buzones no se tocan.');
  console.log('Para confirmar: npm run reiniciar -- --si');
  process.exit(0);
}
await inicializarDB();
for (const t of ['seguimientos', 'borradores', 'alertas', 'mails_procesados', 'buzon_estado', 'meta']) {
  await db().query(`TRUNCATE TABLE ${t}`);
}
await cerrarDB();
console.log('Listo. En el próximo arranque el agente fija un nuevo punto de partida.');
process.exit(0);
