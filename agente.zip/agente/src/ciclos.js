import { log, logError } from './log.js';
import { abrirBuzones, cerrarBuzones } from './mail.js';
import { procesarBuzon } from './procesar.js';
import { cicloRecordatorios } from './recordatorios.js';
import { enviarResumen } from './resumen.js';

export const estado = { ultimoCiclo: null, ultimoResumen: null, ultimoError: null, enCurso: false };

/** Evita que dos ciclos corran a la vez (por ejemplo, si uno tarda más que el intervalo). */
async function exclusivo(nombre, fn, { esperar = false } = {}) {
  // El ciclo diario no se saltea: espera hasta 15 minutos a que termine el ciclo en curso.
  for (let i = 0; esperar && estado.enCurso && i < 90; i++) {
    await new Promise((r) => setTimeout(r, 10_000));
  }
  if (estado.enCurso) {
    log(`${nombre}: hay otro ciclo en curso, se saltea esta vuelta`);
    return null;
  }
  estado.enCurso = true;
  try {
    return await fn();
  } catch (e) {
    estado.ultimoError = { cuando: new Date().toISOString(), donde: nombre, mensaje: e.message };
    logError(`${nombre}: ${e.stack || e.message}`);
    return null;
  } finally {
    estado.enCurso = false;
  }
}

/** Revisa los mails nuevos de todos los buzones. */
export function cicloMails() {
  return exclusivo('Ciclo de mails', async () => {
    const conexiones = await abrirBuzones();
    try {
      for (const cx of conexiones.values()) await procesarBuzon(cx, conexiones);
    } finally {
      await cerrarBuzones(conexiones);
    }
    estado.ultimoCiclo = new Date().toISOString();
  });
}

/** Recordatorios de casos vencidos + resumen diario. */
export function cicloDiario() {
  return exclusivo('Ciclo diario', async () => {
    const conexiones = await abrirBuzones();
    let recordatorios;
    try {
      recordatorios = await cicloRecordatorios(conexiones);
    } finally {
      await cerrarBuzones(conexiones);
    }
    const texto = await enviarResumen({ recordatorios });
    estado.ultimoResumen = new Date().toISOString();
    return texto;
  }, { esperar: true });
}
