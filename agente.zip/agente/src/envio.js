import nodemailer from 'nodemailer';
import MailComposer from 'nodemailer/lib/mail-composer/index.js';
import { config } from './config.js';

// El agente envía solo dos tipos de mail, siempre a destinos fijos del .env:
// alertas urgentes y el resumen diario. Nunca escribe a pacientes.

const admin = config.buzones.find((b) => b.id === 'admin');

let transporte;
function smtp() {
  if (!transporte) {
    transporte = nodemailer.createTransport({
      host: config.smtp.host,
      port: config.smtp.port,
      secure: config.smtp.port === 465,
      auth: { user: admin.email, pass: admin.clave },
    });
  }
  return transporte;
}

export async function verificarSMTP() {
  await smtp().verify();
}

const remitenteInterno = () => `"Agente Secrétariat" <${admin.email}>`;

export async function enviarInterno({ para, asunto, texto }) {
  await smtp().sendMail({
    from: remitenteInterno(),
    to: para,
    subject: asunto,
    text: texto,
    headers: { 'X-Cabinet-Agente': 'interno' },
  });
}

/** Arma el mensaje crudo (RFC 822) de un borrador, listo para guardar por IMAP. */
export async function componerBorrador({ de, para, asunto, cuerpo, inReplyTo, references }) {
  const mail = new MailComposer({
    from: de,
    to: para,
    subject: asunto,
    text: cuerpo,
    inReplyTo: inReplyTo || undefined,
    references: references?.length ? references : undefined,
    headers: { 'X-Cabinet-Agente': 'borrador' },
  });
  return mail.compile().build();
}
