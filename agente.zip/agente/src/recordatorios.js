import { log, logError } from './log.js';
import { config } from './config.js';
import { db } from './db.js';
import { ejecutarAgente } from './llm.js';
import { DEFINICIONES, crearEjecutor } from './herramientas.js';
import { promptSistema } from './procesar.js';
import { fecha } from './fechas.js';

/**
 * Revisa los casos que esperan algo del paciente y cuya fecha de próxima acción ya llegó.
 * Prepara un borrador de recordatorio, o pasa el caso a Agustin si ya hubo demasiados.
 */
export async function cicloRecordatorios(conexiones) {
  const [casos] = await db().query(
    `SELECT * FROM seguimientos
      WHERE estado = 'esperando_paciente' AND fecha_proxima_accion IS NOT NULL AND fecha_proxima_accion <= ?
      ORDER BY fecha_proxima_accion`,
    [fecha()],
  );
  const resultado = { recordatorios: 0, derivados: 0, errores: 0 };

  for (const caso of casos) {
    if (caso.recordatorios >= config.maxRecordatorios) {
      await db().query(
        `UPDATE seguimientos SET estado = 'esperando_agustin', proxima_accion = ?, fecha_proxima_accion = ? WHERE id = ?`,
        [`Sin respuesta tras ${caso.recordatorios} recordatorios: decidir cómo seguir`, fecha(), caso.id],
      );
      resultado.derivados++;
      continue;
    }

    const ctx = {
      modo: 'recordatorio',
      buzon: conexiones.has(caso.buzon) ? caso.buzon : 'admin',
      corresponsal: caso.email,
      nombre: caso.nombre,
      asunto: caso.ultimo_asunto || '',
      messageId: caso.ultimo_message_id,
      references: [],
      caso,
    };

    const tarea = [
      'Tarea de seguimiento: este caso espera algo del remitente y la fecha de próxima acción ya llegó.',
      '',
      `Remitente: ${caso.nombre ? `${caso.nombre} <${caso.email}>` : caso.email}`,
      `Categoría: ${caso.categoria}`,
      `Resumen: ${caso.resumen || '-'}`,
      `Próxima acción prevista: ${caso.proxima_accion || '-'}`,
      `Recordatorios ya preparados: ${caso.recordatorios}`,
      '',
      'Leé el hilo con leer_hilo. Si el remitente ya respondió o ya no hace falta recordar nada, actualizá el caso sin borrador.',
      'Si sigue faltando lo pedido, prepará un recordatorio breve y amable con crear_borrador, en el idioma del hilo,',
      'y actualizá el caso con registrar_seguimiento (estado esperando_paciente).',
    ].join('\n');

    try {
      await ejecutarAgente({
        sistema: promptSistema(),
        usuario: tarea,
        herramientas: DEFINICIONES,
        ejecutar: crearEjecutor(ctx, conexiones),
      });
      if (ctx.borradorCreado) resultado.recordatorios++;
    } catch (e) {
      resultado.errores++;
      logError(`Recordatorio del caso ${caso.id}: ${e.message}`);
    }
  }
  return resultado;
}
