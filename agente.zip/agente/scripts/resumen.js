// Corre los recordatorios y envía el resumen ahora. Uso: npm run resumen
import { inicializarDB, cerrarDB } from '../src/db.js';
import { cicloDiario } from '../src/ciclos.js';

await inicializarDB();
const texto = await cicloDiario();
await cerrarDB();
console.log(texto ?? 'No se pudo generar el resumen (ver el error arriba).');
process.exit(texto ? 0 : 1);
