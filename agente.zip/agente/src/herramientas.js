import { config } from './config.js';
import { db, corto } from './db.js';
import { leerHilo, buscarHistorial, guardarEnCarpeta } from './mail.js';
import { componerBorrador, enviarInterno } from './envio.js';
import { fecha, esFechaValida } from './fechas.js';

export const CATEGORIAS = [
  'nueva_consulta', 'formulario_documentos', 'cita', 'facturacion',
  'proveedor_admin', 'posible_urgencia', 'sin_respuesta', 'otro',
];
export const ESTADOS = ['nuevo', 'esperando_paciente', 'esperando_sofia', 'esperando_agustin', 'cerrado'];

const FIRMA = '\n\nSecrétariat\nCabinet La Bibliothèque Sàrl\nadmin@cabinetlb.ch';

// ─────────────────────────────────────────────────────────────
// Definiciones que ve el modelo
// El destinatario, el mail respondido y el buzón los pone siempre el código:
// el modelo no puede elegir a quién escribir.
// ─────────────────────────────────────────────────────────────

export const DEFINICIONES = [
  {
    type: 'function',
    function: {
      name: 'leer_hilo',
      description:
        'Devuelve la conversación previa del mail que estás procesando (mismo asunto y mismo corresponsal), en orden cronológico, incluidos los mensajes enviados por el cabinet.',
      parameters: { type: 'object', properties: {} },
    },
  },
  {
    type: 'function',
    function: {
      name: 'buscar_historial',
      description:
        'Devuelve los últimos mails intercambiados con el remitente, en cualquier hilo y en ambos buzones, con un extracto de cada uno. Sirve para saber si ya escribió antes.',
      parameters: {
        type: 'object',
        properties: {
          max_resultados: { type: 'integer', description: 'Máximo de mails a devolver (1 a 15).', default: 8 },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'consultar_seguimientos',
      description:
        'Devuelve los casos del tracker. Por defecto, los del remitente actual. También puede filtrar por otra dirección o por estado.',
      parameters: {
        type: 'object',
        properties: {
          email: { type: 'string', description: 'Dirección a consultar. Si se omite, la del remitente actual.' },
          estado: { type: 'string', enum: ESTADOS },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'crear_borrador',
      description:
        'Guarda un borrador de respuesta al remitente, en el mismo hilo. No lo envía: una persona lo revisa y lo envía. Solo un borrador por mail.',
      parameters: {
        type: 'object',
        properties: {
          asunto: { type: 'string', description: "Normalmente 'Re: ' + asunto original." },
          cuerpo: { type: 'string', description: 'Texto completo del mail, con la firma. Sin notas internas.' },
          idioma: { type: 'string', enum: ['fr', 'es', 'en', 'otro'] },
          nota_interna: {
            type: 'string',
            description: 'Nota corta para quien revisa: qué completar, adjuntar o verificar. Nunca va en el mail.',
          },
        },
        required: ['asunto', 'cuerpo', 'idioma', 'nota_interna'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'registrar_seguimiento',
      description:
        'Crea o actualiza el caso del remitente en el tracker. Llamala siempre una vez por mail, al final.',
      parameters: {
        type: 'object',
        properties: {
          nombre: { type: 'string', description: 'Nombre del remitente o del paciente, si se conoce.' },
          categoria: { type: 'string', enum: CATEGORIAS },
          estado: { type: 'string', enum: ESTADOS },
          resumen: { type: 'string', description: 'Una línea administrativa. Nunca contenido clínico.' },
          proxima_accion: { type: 'string', description: 'Qué hay que hacer y quién. Vacío si está cerrado.' },
          fecha_proxima_accion: { type: 'string', description: 'AAAA-MM-DD. Obligatoria salvo si está cerrado.' },
        },
        required: ['categoria', 'estado', 'resumen'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'alerta_urgente',
      description:
        'Avisa de inmediato a Agustin y a Sofia (destinos fijos). Usar ante posible riesgo o crisis, o pedidos de datos de un paciente por terceros.',
      parameters: {
        type: 'object',
        properties: { motivo: { type: 'string', description: 'Una línea explicando por qué.' } },
        required: ['motivo'],
      },
    },
  },
];

// ─────────────────────────────────────────────────────────────
// Implementación
// ─────────────────────────────────────────────────────────────

/**
 * @param {object} ctx  Contexto del mail o del caso que se procesa:
 *   { modo: 'mail'|'recordatorio', buzon, corresponsal, nombre, asunto, messageId, references,
 *     caso?, bloquearBorrador, alertaEnviada, borradorCreado, seguimientoRegistrado }
 * @param {Map} conexiones  Conexiones IMAP abiertas
 */
export function crearEjecutor(ctx, conexiones) {
  const manejadores = {
    async leer_hilo() {
      const mensajes = await leerHilo(
        conexiones,
        { asunto: ctx.asunto, references: ctx.references, inReplyTo: ctx.messageId },
        ctx.corresponsal,
      );
      return { mensajes };
    },

    async buscar_historial({ max_resultados }) {
      const max = Math.min(15, Math.max(1, parseInt(max_resultados, 10) || 8));
      return { mails: await buscarHistorial(conexiones, ctx.corresponsal, max) };
    },

    async consultar_seguimientos({ email, estado }) {
      const filtros = [];
      const valores = [];
      if (estado) {
        if (!ESTADOS.includes(estado)) return { error: `Estado inválido: ${estado}` };
        filtros.push('estado = ?');
        valores.push(estado);
      }
      if (email || !estado) {
        filtros.push('email = ?');
        valores.push(String(email || ctx.corresponsal).toLowerCase());
      }
      const [filas] = await db().query(
        `SELECT id, email, nombre, categoria, estado, resumen, proxima_accion, fecha_proxima_accion,
                recordatorios, DATE_FORMAT(actualizado, '%Y-%m-%d') AS actualizado
           FROM seguimientos WHERE ${filtros.join(' AND ')} ORDER BY actualizado DESC LIMIT 20`,
        valores,
      );
      return { casos: filas };
    },

    async crear_borrador({ asunto, cuerpo, idioma, nota_interna }) {
      if (ctx.bloquearBorrador) {
        return { error: 'Bloqueado: este mail tiene posibles señales de riesgo. No se hace borrador; ya se envió una alerta.' };
      }
      if (ctx.borradorCreado) return { error: 'Ya creaste un borrador para este mail.' };
      if (!cuerpo || String(cuerpo).trim().length < 20) return { error: 'El cuerpo está vacío o es demasiado corto.' };

      let texto = String(cuerpo).trim();
      if (!texto.includes('Cabinet La Bibliothèque Sàrl')) texto += FIRMA;

      const destino = config.modoPrueba || config.borradoresEn === 'admin' ? 'admin' : ctx.buzon;
      const cx = conexiones.get(destino);
      const carpeta = config.modoPrueba ? config.carpetaPruebas : cx.carpetas.borradores;

      const crudo = await componerBorrador({
        de: `"${config.nombreRemitente}" <${cx.buzon.email}>`,
        para: ctx.corresponsal,
        asunto: corto(asunto, 200) || `Re: ${ctx.asunto}`,
        cuerpo: texto,
        inReplyTo: ctx.messageId,
        references: [...(ctx.references || []), ctx.messageId].filter(Boolean),
      });
      await guardarEnCarpeta(cx, carpeta, crudo);

      const nota = ctx.buzon !== destino ? `[llegó a ${ctx.buzon}@] ${nota_interna || ''}` : nota_interna;
      await db().query(
        `INSERT INTO borradores (buzon_origen, buzon_borrador, para, asunto, idioma, nota_interna, es_recordatorio, modo_prueba)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [ctx.buzon, destino, ctx.corresponsal, corto(asunto, 500), idioma, corto(nota, 1000),
          ctx.modo === 'recordatorio' ? 1 : 0, config.modoPrueba ? 1 : 0],
      );

      if (ctx.modo === 'recordatorio' && ctx.caso) {
        await db().query(
          `UPDATE seguimientos SET recordatorios = recordatorios + 1, fecha_proxima_accion = ? WHERE id = ?`,
          [fecha(config.diasEntreRecordatorios), ctx.caso.id],
        );
      }
      ctx.borradorCreado = true;
      return { ok: true, guardado_en: `${cx.buzon.email} / ${carpeta}` };
    },

    async registrar_seguimiento({ nombre, categoria, estado, resumen, proxima_accion, fecha_proxima_accion }) {
      if (!CATEGORIAS.includes(categoria)) return { error: `Categoría inválida: ${categoria}` };
      if (!ESTADOS.includes(estado)) return { error: `Estado inválido: ${estado}` };

      let fechaAccion = null;
      if (estado !== 'cerrado') {
        fechaAccion = esFechaValida(fecha_proxima_accion) ? fecha_proxima_accion : fecha(config.diasEntreRecordatorios);
      }
      const datos = [
        corto(nombre, 200), categoria, estado, corto(resumen, 500),
        estado === 'cerrado' ? null : corto(proxima_accion, 500), fechaAccion,
      ];

      let id = ctx.caso?.id;
      if (!id) {
        const [abiertos] = await db().query(
          `SELECT id FROM seguimientos WHERE email = ? AND estado <> 'cerrado' ORDER BY actualizado DESC LIMIT 1`,
          [ctx.corresponsal],
        );
        id = abiertos[0]?.id;
      }

      if (id) {
        // Si llegó un mail nuevo del remitente, se reinicia el contador de recordatorios.
        const reinicio = ctx.modo === 'mail' ? ', recordatorios = 0, buzon = ?, ultimo_message_id = ?, ultimo_asunto = ?' : '';
        const extra = ctx.modo === 'mail' ? [ctx.buzon, corto(ctx.messageId, 500), corto(ctx.asunto, 500)] : [];
        await db().query(
          `UPDATE seguimientos SET nombre = COALESCE(?, nombre), categoria = ?, estado = ?, resumen = ?,
             proxima_accion = ?, fecha_proxima_accion = ?${reinicio} WHERE id = ?`,
          [...datos, ...extra, id],
        );
      } else {
        const [r] = await db().query(
          `INSERT INTO seguimientos (nombre, categoria, estado, resumen, proxima_accion, fecha_proxima_accion,
             email, buzon, ultimo_message_id, ultimo_asunto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [...datos, ctx.corresponsal, ctx.buzon, corto(ctx.messageId, 500), corto(ctx.asunto, 500)],
        );
        id = r.insertId;
      }
      ctx.seguimientoRegistrado = true;
      return { ok: true, caso_id: id, fecha_proxima_accion: fechaAccion };
    },

    async alerta_urgente({ motivo }) {
      if (ctx.alertaEnviada) return { ok: true, nota: 'La alerta ya fue enviada para este mail.' };
      await enviarAlerta(ctx, motivo, 'agente');
      return { ok: true };
    },
  };

  return async (nombre, args) => {
    const fn = manejadores[nombre];
    if (!fn) return { error: `Herramienta desconocida: ${nombre}` };
    return fn(args || {});
  };
}

/** Alerta inmediata a los destinos fijos. No incluye el contenido del mail. */
export async function enviarAlerta(ctx, motivo, origen) {
  const buzonEmail = config.buzones.find((b) => b.id === ctx.buzon)?.email || ctx.buzon;
  await enviarInterno({
    para: config.alertaDestinos.join(', '),
    asunto: `[ALERTA] Mail a revisar ya en ${buzonEmail}`,
    texto: [
      'El agente marcó un mail para revisión inmediata. No se preparó ningún borrador.',
      '',
      `Motivo: ${motivo}`,
      `Buzón: ${buzonEmail}`,
      `De: ${ctx.nombre ? `${ctx.nombre} <${ctx.corresponsal}>` : ctx.corresponsal}`,
      `Asunto: ${ctx.asunto || '(sin asunto)'}`,
      ctx.fecha ? `Recibido: ${ctx.fecha}` : '',
      '',
      'Abrí el buzón para leer el mensaje completo.',
    ].filter((l) => l !== null).join('\n'),
  });
  await db().query(
    'INSERT INTO alertas (buzon, remitente, asunto, motivo, origen) VALUES (?, ?, ?, ?, ?)',
    [ctx.buzon, ctx.corresponsal, corto(ctx.asunto, 500), corto(motivo, 500), origen],
  );
  ctx.alertaEnviada = true;
  ctx.bloquearBorrador = true;
}
