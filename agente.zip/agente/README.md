# Agente de secretariado — Cabinet La Bibliothèque

Lee los buzones `admin@` y `sofia@cabinetlb.ch`, prepara borradores de respuesta, lleva el seguimiento de cada caso y avisa ante urgencias. Corre en Infomaniak, igual que el gestor, y la IA también es de Infomaniak (servidores en Suiza).

## Qué hace

**Cada 10 minutos**, por cada mail nuevo:

1. Descarta lo que no necesita respuesta: newsletters, respuestas automáticas y mails internos.
2. Pasa el texto por un **filtro de riesgo** que no depende de la IA. Si detecta señales de crisis, alerta a Agustin y a Sofia y bloquea el borrador.
3. El agente lee el hilo, el historial y el tracker. Después clasifica el mail, prepara el borrador y registra el caso.

**Lunes a viernes a las 7:30**:

1. Revisa los casos que esperan algo del paciente y ya vencieron. Si sigue faltando lo pedido, prepara un recordatorio.
2. Después de 2 recordatorios sin respuesta, pasa el caso a Agustin.
3. Envía el resumen del día: alertas, borradores para revisar, qué espera a Sofia, a Agustin y a los pacientes, y si hubo errores.

## Qué no puede hacer

- **Enviar mails a pacientes.** Solo guarda borradores. Los únicos mails que envía son las alertas y el resumen, a los destinos fijos de la configuración.
- **Elegir el destinatario.** El borrador siempre responde al remitente del mail que procesa, y eso lo pone el código, no la IA.
- **Borrar, mover o marcar mails como leídos.** Lee los buzones en modo solo lectura.
- **Guardar el contenido de los mails.** La base solo tiene datos administrativos: remitente, asunto, estado y fechas.

## Archivos

| Archivo | Para qué |
|---|---|
| `configuracion.env` | Contraseñas y ajustes. Se completa una vez. |
| `instrucciones.md` | El manual de la secretaria. Se edita libremente; los cambios aplican al reiniciar. |
| `src/` | El código del agente. |
| `scripts/` | Pruebas y ejecuciones manuales (opcionales, por SSH). |

---

## Instalación dentro del gestor (Infomaniak)

El agente corre dentro del mismo sitio Node.js que el gestor, en una carpeta `agente/` aparte. No abre ningún puerto, no usa nada del gestor y está protegido para que, si falla, el gestor siga funcionando igual.

Todo se hace desde el Manager de Infomaniak, con la herramienta **Web FTP**. No hace falta descomprimir nada en tu computadora.

### Paso 1 — Crear la base de datos

1. En el Manager, entrá a **Web Hosting 1 → Databases**.
2. Creá una base de datos nueva. Infomaniak le agrega un prefijo al nombre: anotá el nombre completo.
3. Creá un usuario con acceso a esa base y anotá usuario y contraseña.
4. Anotá el **servidor (host)** que aparece en esa misma página.

No hace falta crear tablas: el agente las crea solo.

### Paso 2 — Subir el agente

1. En **Web Hosting 1 → FTP / SSH**, tocá el botón **Web FTP**.
2. Entrá a la carpeta del gestor: la que tiene su `package.json`.
3. Subí `agente.zip` ahí, sin descomprimirlo antes.
4. Usá la opción **dézipper** sobre el archivo. Tiene que quedar una carpeta `agente` al lado del `package.json` del gestor. Después podés borrar el ZIP.

### Paso 3 — Completar la configuración

Desde el mismo Web FTP, abrí `agente/configuracion.env` con la opción de editar y completá:

- `ADMIN_PASSWORD` y `SOFIA_PASSWORD`: las mismas que se usan en el celular o en Outlook.
- `INFOMANIAK_API_TOKEN`: el token de AI Services. El Product ID ya está cargado.
- `DB_HOST`, `DB_USER`, `DB_PASSWORD` y `DB_NAME`: los del paso 1.

Guardá.

### Paso 4 — Conectar el agente al gestor

1. En el Manager, abrí el sitio del gestor y entrá a **Gérer les paramètres avancés → Node.js**.
2. Mirá la **Commande de lancement**: ahí dice cuál es el archivo principal del gestor (por ejemplo `node server.js`, o `npm start`, que apunta al `main` o al script `start` de su `package.json`).
3. En **Commande de construction (Build)**, agregá al final de lo que ya haya:
   ```
    && (npm install --prefix agente --omit=dev || true)
   ```
   Si estaba vacía, poné solo `npm install --prefix agente --omit=dev || true`. El `|| true` hace que, si la instalación del agente falla, el gestor se instale igual.
4. Con Web FTP, abrí el archivo principal del gestor y agregá esta línea **al final**:
   ```js
   import('./agente/src/integrado.js').catch((e) => console.error('[agente] no arrancó:', e.message));
   ```
   Si el archivo principal está dentro de una subcarpeta (por ejemplo `src/server.js`), la ruta es `'../agente/src/integrado.js'`.
5. Guardá y tocá **Restart** en el panel del sitio.

### Paso 5 — Leer el autodiagnóstico

Abrí la consola de ejecución del sitio. Las líneas del agente empiezan con `[agente]`:

```
[agente] arrancando (MODO PRUEBA, ...)
[agente] ── Prueba de conexiones ──
1. Buzones (IMAP)
  ✓ admin@cabinetlb.ch: conectado ...
  ✓ sofia@cabinetlb.ch: conectado ...
2. Envío (SMTP)
  ✓ login SMTP correcto ...
3. Base de datos (MySQL)
  ✓ conectado ...
4. IA (Infomaniak AI Services)
  ✓ conectado; N modelos disponibles: ...
  ✓ el modelo usa herramientas ...
Todo listo.
```

Si algo sale con ✗, el mensaje dice qué falta. La consola no muestra contraseñas, así que se puede copiar y mandar para revisar.

### Paso 6 — Revisar en modo prueba durante una o dos semanas

- Los borradores aparecen en Infomaniak Mail, en una carpeta **Agente-Pruebas** del buzón `admin@`. No van a Brouillons, así no hay riesgo de enviar uno por error.
- Como `PROCESAR_ULTIMOS_DIAS=7`, en el primer arranque procesa la última semana, así hay material para revisar desde el primer día.
- Las alertas y el resumen de las 7:30 se envían normalmente.
- Si algo se repite (un tono, una fórmula, un caso mal clasificado), se corrige en `agente/instrucciones.md`.

### Paso 7 — Pasar a producción

En `agente/configuracion.env`, cambiá `MODO_PRUEBA=true` por `MODO_PRUEBA=false` y reiniciá el sitio. Desde ahí, los borradores aparecen en Brouillons de `admin@`, en el mismo hilo que el mail del paciente.

### Apagar el agente

Borrá (o comentá con `//`) la línea agregada en el archivo principal del gestor y reiniciá. El gestor queda exactamente como antes.

---

## Cambiar algo después

Editá `agente/configuracion.env` o `agente/instrucciones.md` con Web FTP y tocá **Restart** en el panel del sitio.

## Alternativa: sitio propio

Si en algún momento el plan permite otro sitio Node.js, el agente también corre solo: carpeta de ejecución `./agente`, build `npm install --omit=dev`, lanzamiento `npm start`. En ese modo responde en `/salud` con su estado.

## Comandos (opcionales, por SSH)

| Comando | Qué hace |
|---|---|
| `npm run probar` | Prueba todas las conexiones. |
| `npm run ciclo` | Revisa los buzones una vez, ahora. |
| `npm run resumen` | Hace los recordatorios y envía el resumen, ahora. |
| `npm run reiniciar -- --si` | Vacía el tracker y el historial del agente (no toca los buzones). |

## Próximo paso: el gestor

Se agregan herramientas de solo lectura para pacientes, lista de espera, derivados y agenda, más la escritura en Tareas. Después, el tracker puede pasar a vivir en el módulo Tareas del gestor.
