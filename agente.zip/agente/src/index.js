// Punto de entrada para correr el agente como sitio Node.js independiente.
// (Si corre dentro del gestor, se usa src/integrado.js en su lugar.)
import http from 'node:http';
import { iniciarAgente } from './arranque.js';
import { log } from './log.js';

const agente = await iniciarAgente();
if (!agente) process.exit(1);
const { config, estado } = agente;

// Estado mínimo en /salud, sin ningún dato de pacientes.
http
  .createServer((req, res) => {
    if (req.url === '/salud') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true,
        modoPrueba: config.modoPrueba,
        ultimoCiclo: estado.ultimoCiclo,
        ultimoResumen: estado.ultimoResumen,
        ultimoError: estado.ultimoError ? { cuando: estado.ultimoError.cuando, donde: estado.ultimoError.donde } : null,
      }));
      return;
    }
    res.writeHead(404);
    res.end();
  })
  .listen(config.puerto, () => log(`escuchando en el puerto ${config.puerto}`));

for (const senal of ['SIGTERM', 'SIGINT']) {
  process.on(senal, () => process.exit(0));
}
