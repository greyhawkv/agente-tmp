import OpenAI from 'openai';
import { config } from './config.js';

// Infomaniak AI Tools expone una API compatible con OpenAI, alojada en Suiza.
export const llm = new OpenAI({
  baseURL: config.llm.baseURL,
  apiKey: config.llm.apiKey,
  timeout: 120_000,
  maxRetries: 3,
});

/**
 * Bucle del agente: el modelo decide qué herramienta usar, el código la ejecuta
 * y le devuelve el resultado, hasta que el modelo termina o se alcanza el máximo de pasos.
 *
 * @param {object} p
 * @param {string} p.sistema       Instrucciones del agente
 * @param {string} p.usuario       Tarea concreta (el mail a procesar, o el caso a recordar)
 * @param {Array}  p.herramientas  Definiciones de herramientas (formato OpenAI)
 * @param {(nombre: string, args: object) => Promise<object>} p.ejecutar
 */
export async function ejecutarAgente({ sistema, usuario, herramientas, ejecutar, maxPasos = 12 }) {
  const mensajes = [
    { role: 'system', content: sistema },
    { role: 'user', content: usuario },
  ];
  const llamadas = [];

  for (let paso = 1; paso <= maxPasos; paso++) {
    const respuesta = await llm.chat.completions.create({
      model: config.llm.modelo,
      messages: mensajes,
      tools: herramientas,
      tool_choice: 'auto',
      temperature: 0.2,
    });
    const msg = respuesta.choices?.[0]?.message;
    if (!msg) throw new Error('Respuesta vacía del modelo');

    const toolCalls = msg.tool_calls || [];
    mensajes.push({ role: 'assistant', content: msg.content ?? '', ...(toolCalls.length ? { tool_calls: toolCalls } : {}) });

    if (!toolCalls.length) return { final: msg.content || '', llamadas, pasos: paso };

    for (const tc of toolCalls) {
      const nombre = tc.function?.name;
      let resultado;
      let args;
      try {
        args = JSON.parse(tc.function?.arguments || '{}');
      } catch {
        args = null;
      }
      if (!args || typeof args !== 'object') {
        resultado = { error: 'Los argumentos no son un JSON válido. Volvé a intentarlo.' };
      } else {
        try {
          resultado = await ejecutar(nombre, args);
        } catch (e) {
          resultado = { error: e.message };
        }
      }
      llamadas.push({ nombre, ok: !resultado?.error });
      mensajes.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(resultado) });
    }
  }
  throw new Error(`El agente superó el máximo de ${maxPasos} pasos`);
}
