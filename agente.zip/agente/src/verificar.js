// Prueba cada conexión por separado y dice qué falta.
// Se ejecuta sola al arrancar el agente (el resultado aparece en la consola del sitio)
// y también a mano con "npm run probar". No procesa mails, no crea borradores y no envía nada.

import { config } from './config.js';
import { abrirBuzones, cerrarBuzones, estadoInbox } from './mail.js';
import { verificarSMTP } from './envio.js';
import { inicializarDB, db } from './db.js';
import { llm } from './llm.js';

export async function verificarConexiones() {
  const lineas = [];
  let fallas = 0;
  const ok = (m) => lineas.push(`  ✓ ${m}`);

  async function paso(titulo, fn) {
    lineas.push(titulo);
    try {
      await fn();
    } catch (e) {
      fallas++;
      lineas.push(`  ✗ ${e.message}`);
    }
  }

  await paso('1. Buzones (IMAP)', async () => {
    const conexiones = await abrirBuzones();
    try {
      for (const cx of conexiones.values()) {
        const { uidNext } = await estadoInbox(cx);
        ok(`${cx.buzon.email}: conectado · enviados="${cx.carpetas.enviados}" · borradores="${cx.carpetas.borradores}" · ~${uidNext - 1} mails en INBOX`);
      }
    } finally {
      await cerrarBuzones(conexiones);
    }
  });

  await paso('2. Envío (SMTP)', async () => {
    await verificarSMTP();
    ok(`login SMTP correcto con ${config.buzones[0].email}`);
  });

  await paso('3. Base de datos (MySQL)', async () => {
    await inicializarDB();
    const [filas] = await db().query('SELECT COUNT(*) AS n FROM seguimientos');
    ok(`conectado a ${config.db.database}; tablas listas (${filas[0].n} seguimientos)`);
  });

  await paso('4. IA (Infomaniak AI Services)', async () => {
    const modelos = await llm.models.list();
    const ids = modelos.data.map((m) => m.id);
    ok(`conectado; ${ids.length} modelos disponibles:`);
    for (const id of ids) lineas.push(`      ${id === config.llm.modelo ? '→' : ' '} ${id}`);
    if (!ids.includes(config.llm.modelo)) {
      throw new Error(`El modelo "${config.llm.modelo}" no está en la lista. Elegí uno de arriba en MODELO.`);
    }
    const r = await llm.chat.completions.create({
      model: config.llm.modelo,
      temperature: 0,
      messages: [{ role: 'user', content: 'Registrá un caso de prueba para test@example.com con estado nuevo.' }],
      tools: [{
        type: 'function',
        function: {
          name: 'registrar_caso',
          description: 'Registra un caso',
          parameters: {
            type: 'object',
            properties: { email: { type: 'string' }, estado: { type: 'string', enum: ['nuevo', 'cerrado'] } },
            required: ['email', 'estado'],
          },
        },
      }],
    });
    const tc = r.choices[0].message.tool_calls?.[0];
    if (!tc) {
      throw new Error(`El modelo respondió sin usar herramientas: "${String(r.choices[0].message.content).slice(0, 120)}". Probá otro modelo.`);
    }
    ok(`el modelo usa herramientas: ${tc.function.name}(${tc.function.arguments})`);
  });

  lineas.push(fallas ? `${fallas} prueba(s) fallaron.` : 'Todo listo.');
  return { fallas, texto: lineas.join('\n') };
}
