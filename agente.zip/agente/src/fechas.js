import { config } from './config.js';

/** Fecha AAAA-MM-DD en la zona horaria del cabinet, con un desplazamiento opcional en días. */
export function fecha(dias = 0) {
  const d = new Date(Date.now() + dias * 86_400_000);
  return new Intl.DateTimeFormat('en-CA', { timeZone: config.zona }).format(d);
}

export function diaDeLaSemana() {
  return new Intl.DateTimeFormat('fr-CH', { timeZone: config.zona, weekday: 'long' }).format(new Date());
}

export function esFechaValida(s) {
  return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s));
}

export function ahoraLegible() {
  return new Intl.DateTimeFormat('es-AR', {
    timeZone: config.zona,
    dateStyle: 'full',
    timeStyle: 'short',
  }).format(new Date());
}
