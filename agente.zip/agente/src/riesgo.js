// Red de seguridad independiente del modelo de IA.
// Si el texto contiene alguna de estas expresiones, se alerta siempre y se bloquea el borrador,
// aunque el modelo no lo detecte. Es preferible una falsa alarma a un mail no visto.

const PATRONES = [
  // Francés
  /suicid/, /me tuer/, /mettre fin a mes jours/, /en finir avec (la vie|tout)/, /plus envie de vivre/,
  /envie de mourir/, /me faire du mal/, /automutil/, /scarifi/, /me (faire )?disparaitre/,
  /(le|la|les) tuer\b/, /je vais (le|la|les) frapper/,
  // Español
  /matarme/, /quitarme la vida/, /no quiero (seguir )?vivir/, /ganas de morir/, /hacerme dano/,
  /autolesi/, /cortarme/, /desaparecer para siempre/, /(lo|la|los) voy a matar/,
  // Inglés
  /kill myself/, /end my life/, /want to die/, /self[- ]?harm/, /hurt myself/, /cutting myself/,
  /(kill|hurt) (him|her|them)\b/,
];
// Palabras como "urgent" o "crise" no están acá a propósito: aparecen en muchos mails
// administrativos ("facture urgente"). Esas las evalúa el modelo según las instrucciones.

function normalizar(texto) {
  return String(texto || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/\s+/g, ' ');
}

/** Devuelve la expresión encontrada (sin acentos), o null. */
export function detectarRiesgo(...textos) {
  const t = normalizar(textos.join(' ')).replace(/[’`]/g, "'");
  for (const re of PATRONES) {
    const m = t.match(re);
    if (m) return m[0];
  }
  return null;
}
