// Corre un ciclo de mails una vez, a mano. Uso: npm run ciclo
import { inicializarDB, cerrarDB } from '../src/db.js';
import { cicloMails } from '../src/ciclos.js';

await inicializarDB();
await cicloMails();
await cerrarDB();
console.log('Ciclo terminado.');
process.exit(0);
