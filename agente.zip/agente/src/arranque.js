import { log, logError } from './log.js';

/**
 * Arranca el agente: carga la configuración, prueba las conexiones y programa los ciclos.
 * Nunca lanza errores hacia afuera: si algo falla, lo escribe en la consola y sigue
 * (o no arranca), pero no afecta al programa que lo cargó.
 *
 * @returns {Promise<{config, estado} | null>}
 */
export async function iniciarAgente() {
  if (globalThis.__agenteCabinetIniciado) {
    log('ya estaba iniciado; no se arranca dos veces');
    return null;
  }
  globalThis.__agenteCabinetIniciado = true;

  let config;
  try {
    ({ config } = await import('./config.js'));
  } catch (e) {
    logError(`✗ CONFIGURACIÓN INCOMPLETA: ${e.message}`);
    logError('  Completá agente/configuracion.env y reiniciá el sitio. El agente no arrancó.');
    return null;
  }

  try {
    const { default: cron } = await import('node-cron');
    const { inicializarDB } = await import('./db.js');
    const { cicloMails, cicloDiario, estado } = await import('./ciclos.js');
    const { verificarConexiones } = await import('./verificar.js');

    log(
      `arrancando (${config.modoPrueba ? 'MODO PRUEBA' : 'PRODUCCIÓN'}, ciclo cada ${config.minutosEntreCiclos} min, ` +
        `resumen "${config.cronResumen}", modelo ${config.llm.modelo})`,
    );

    const { fallas, texto } = await verificarConexiones();
    log(`── Prueba de conexiones ──\n${texto}`);
    if (fallas) log('sigue corriendo, pero no va a funcionar bien hasta corregir lo marcado con ✗.');

    await inicializarDB().catch((e) => logError(`Base de datos: ${e.message}`));

    cron.schedule(`*/${config.minutosEntreCiclos} * * * *`, () => cicloMails(), { timezone: config.zona });
    cron.schedule(config.cronResumen, () => cicloDiario(), { timezone: config.zona });

    if (!fallas) cicloMails();
    return { config, estado };
  } catch (e) {
    logError(`no pudo arrancar: ${e.stack || e.message}`);
    return null;
  }
}
