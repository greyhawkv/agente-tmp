import { config } from './config.js';
import { db, leerMeta, guardarMeta } from './db.js';
import { enviarInterno } from './envio.js';
import { ahoraLegible, fecha } from './fechas.js';

const ETIQUETA = (caso) => (caso.nombre ? `${caso.nombre} <${caso.email}>` : caso.email);

function seccion(titulo, items) {
  if (!items.length) return null;
  return [`${titulo} (${items.length})`, ...items, ''].join('\n');
}

/** Arma y envía el resumen con todo lo ocurrido desde el resumen anterior. */
export async function enviarResumen(extra = {}) {
  const desde = {
    borrador: Number(await leerMeta('resumen_borrador_id')) || 0,
    alerta: Number(await leerMeta('resumen_alerta_id')) || 0,
    mail: Number(await leerMeta('resumen_mail_id')) || 0,
  };

  const [alertas] = await db().query('SELECT * FROM alertas WHERE id > ? ORDER BY id', [desde.alerta]);
  const [borradores] = await db().query('SELECT * FROM borradores WHERE id > ? ORDER BY id', [desde.borrador]);
  const [mails] = await db().query('SELECT * FROM mails_procesados WHERE id > ? ORDER BY id', [desde.mail]);
  const [abiertos] = await db().query(
    `SELECT * FROM seguimientos WHERE estado <> 'cerrado' ORDER BY fecha_proxima_accion IS NULL, fecha_proxima_accion`,
  );

  const hoy = fecha();
  const porEstado = (e) => abiertos.filter((c) => c.estado === e);
  const linea = (c) => {
    const vencido = c.fecha_proxima_accion && c.fecha_proxima_accion < hoy ? ' ⚠ vencido' : '';
    return `• ${ETIQUETA(c)} — ${c.resumen || c.categoria}\n  Próxima acción: ${c.proxima_accion || '-'} (${c.fecha_proxima_accion || 'sin fecha'})${vencido}`;
  };

  const problemas = mails.filter((m) => ['error', 'incompleto'].includes(m.resultado));
  const omitidos = mails.filter((m) => m.resultado === 'omitido').length;
  const procesados = mails.filter((m) => m.resultado !== 'reintentar').length;

  const cuerpo = [
    `Resumen del agente — ${ahoraLegible()}`,
    '',
    config.modoPrueba
      ? `MODO PRUEBA: los borradores están en la carpeta "${config.carpetaPruebas}" de ${config.buzones[0].email}, no en Brouillons.\n`
      : null,
    seccion('ALERTAS', alertas.map((a) => `• ${a.remitente} — "${a.asunto || '(sin asunto)'}" (${a.buzon})\n  ${a.motivo}`)),
    seccion(
      'BORRADORES PARA REVISAR',
      borradores.map(
        (b) => `• Para ${b.para} — "${b.asunto}"${b.es_recordatorio ? ' [recordatorio]' : ''}\n  Nota: ${b.nota_interna || '-'}`,
      ),
    ),
    seccion('ESPERANDO A SOFIA', porEstado('esperando_sofia').map(linea)),
    seccion('ESPERANDO A AGUSTIN', porEstado('esperando_agustin').map(linea)),
    seccion('ESPERANDO AL PACIENTE', porEstado('esperando_paciente').map(linea)),
    seccion('NUEVOS SIN CLASIFICAR', porEstado('nuevo').map(linea)),
    seccion(
      'PROBLEMAS',
      problemas.map((m) => `• [${m.buzon}] ${m.remitente || '?'} — "${m.asunto || ''}"\n  ${m.detalle || m.resultado}`),
    ),
    `Mails revisados desde el último resumen: ${procesados}. Sin respuesta necesaria (newsletters, automáticos, internos): ${omitidos}.`,
    extra.recordatorios
      ? `Recordatorios preparados hoy: ${extra.recordatorios.recordatorios}. Casos pasados a Agustin por falta de respuesta: ${extra.recordatorios.derivados}.`
      : null,
  ]
    .filter((p) => p !== null)
    .join('\n');

  await enviarInterno({
    para: config.resumenDestino,
    asunto: `Resumen del secretariado — ${hoy}${alertas.length ? ` — ${alertas.length} alerta(s)` : ''}`,
    texto: cuerpo,
  });

  const max = (filas) => (filas.length ? filas[filas.length - 1].id : null);
  if (max(alertas)) await guardarMeta('resumen_alerta_id', max(alertas));
  if (max(borradores)) await guardarMeta('resumen_borrador_id', max(borradores));
  if (max(mails)) await guardarMeta('resumen_mail_id', max(mails));
  return cuerpo;
}
