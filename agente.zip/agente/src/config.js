import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

// Ajustes y contraseñas: archivo configuracion.env en la carpeta del agente.
// Se leen en un objeto propio, sin tocar process.env: así el agente puede correr
// dentro del proceso del gestor sin mezclar sus variables con las del gestor.
// (Solo si se define AGENTE_CONFIG=env se usan las variables de entorno, por ejemplo en pruebas.)
const carpeta = fileURLToPath(new URL('..', import.meta.url));
const archivo = carpeta + 'configuracion.env';
const vars = {};
if (process.env.AGENTE_CONFIG === 'env') {
  Object.assign(vars, process.env);
} else if (existsSync(archivo)) {
  dotenv.config({ path: archivo, processEnv: vars, quiet: true });
} else {
  throw new Error(`No se encontró ${archivo}`);
}

function requerida(nombre) {
  const valor = vars[nombre];
  if (!valor || !String(valor).trim()) {
    throw new Error(`Falta completar ${nombre} en configuracion.env`);
  }
  return String(valor).trim();
}

function opcional(nombre, porDefecto) {
  const valor = vars[nombre];
  return valor && String(valor).trim() ? String(valor).trim() : porDefecto;
}

function entero(nombre, porDefecto) {
  const n = parseInt(opcional(nombre, String(porDefecto)), 10);
  return Number.isFinite(n) ? n : porDefecto;
}

const adminEmail = requerida('ADMIN_EMAIL').toLowerCase();
const sofiaEmail = requerida('SOFIA_EMAIL').toLowerCase();

export const config = {
  modoPrueba: opcional('MODO_PRUEBA', 'true') !== 'false',
  carpetaPruebas: opcional('CARPETA_PRUEBAS', 'Agente-Pruebas'),

  imap: { host: opcional('IMAP_HOST', 'mail.infomaniak.com'), port: entero('IMAP_PORT', 993) },
  smtp: { host: opcional('SMTP_HOST', 'mail.infomaniak.com'), port: entero('SMTP_PORT', 465) },

  buzones: [
    { id: 'admin', email: adminEmail, clave: requerida('ADMIN_PASSWORD') },
    { id: 'sofia', email: sofiaEmail, clave: requerida('SOFIA_PASSWORD') },
  ],

  borradoresEn: opcional('BORRADORES_EN', 'admin') === 'mismo' ? 'mismo' : 'admin',
  nombreRemitente: 'Secrétariat – Cabinet La Bibliothèque',

  alertaDestinos: requerida('ALERTA_DESTINOS').split(',').map((s) => s.trim()).filter(Boolean),
  resumenDestino: requerida('RESUMEN_DESTINO'),

  llm: {
    // Se puede forzar otra URL con INFOMANIAK_BASE_URL (por ejemplo, si Infomaniak cambia la versión de la API).
    baseURL: opcional(
      'INFOMANIAK_BASE_URL',
      `https://api.infomaniak.com/2/ai/${requerida('INFOMANIAK_PRODUCT_ID')}/openai/v1`,
    ),
    apiKey: requerida('INFOMANIAK_API_TOKEN'),
    modelo: opcional('MODELO', 'Qwen/Qwen3.5-122B-A10B-FP8'),
  },

  db: {
    host: requerida('DB_HOST'),
    port: entero('DB_PORT', 3306),
    user: requerida('DB_USER'),
    password: requerida('DB_PASSWORD'),
    database: requerida('DB_NAME'),
  },

  zona: opcional('ZONA_HORARIA', 'Europe/Zurich'),
  minutosEntreCiclos: Math.max(5, entero('MINUTOS_ENTRE_CICLOS', 10)),
  cronResumen: opcional('CRON_RESUMEN', '30 7 * * 1-5'),

  diasEntreRecordatorios: entero('DIAS_ENTRE_RECORDATORIOS', 5),
  maxRecordatorios: entero('MAX_RECORDATORIOS', 2),
  procesarUltimosDias: entero('PROCESAR_ULTIMOS_DIAS', 0),

  // Solo para el modo independiente (sitio propio). Infomaniak asigna el puerto en PORT.
  puerto: parseInt(process.env.PORT, 10) || 3000,
};

/** Direcciones propias del cabinet (para no procesar lo que envía el propio agente). */
export const direccionesPropias = new Set(config.buzones.map((b) => b.email));
